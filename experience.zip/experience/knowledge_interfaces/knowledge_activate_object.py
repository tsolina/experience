from experience.knowledge_interfaces.knowledge_object import KnowledgeObject

class KnowledgeActivateObject(KnowledgeObject):
    def __init__(self, com):
        super().__init__(com)
        self.knowledge_activate_object = com

    @property
    def activated(self) -> bool:
        return self.knowledge_activate_object.Activated

    def activate(self) -> None:
        return self.knowledge_activate_object.Activate()

    def deactivate(self) -> None:
        return self.knowledge_activate_object.Deactivate()

    def __repr__(self):
        return f'KnowledgeActivateObject(name="{ self.name }")'    
