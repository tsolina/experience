from experience.knowledge_interfaces.enum_param import EnumParam

class BoolParam(EnumParam):
    def __init__(self, com):
        super().__init__(com)
        self.bool_param = com

    @property
    def value(self) -> bool:
        return self.bool_param.Value

    @value.setter
    def value(self, value: bool):
        self.bool_param.Value = value

    def __repr__(self):
        return f'BoolParam(name="{self.name}")'    
