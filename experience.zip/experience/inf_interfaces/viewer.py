from typing import TYPE_CHECKING

from experience.inf_interfaces.camera import Camera
from experience.system.any_object import AnyObject

if TYPE_CHECKING:
    from experience.inf_interfaces.viewer2d import Viewer2D
    from experience.inf_interfaces.viewer3d import Viewer3D

class Viewer(AnyObject):
    def __init__(self, com):
        super().__init__(com)
        self.viewer = com

    @property
    def full_screen(self) -> bool:
        return self.viewer.FullScreen

    @full_screen.setter
    def full_screen(self, value: bool):
        self.viewer.FullScreen = value

    @property
    def height(self) -> int:
        return self.viewer.Height

    @property
    def width(self) -> int:
        return self.viewer.Width

    def activate(self) -> None:
        return self.viewer.Activate()

    def capture_to_file(self, i_format: int, i_file: str) -> None:
        return self.viewer.CaptureToFile(i_format, i_file)

    def get_background_color(self) -> tuple:
        return self._get_safe_array(self._com, "GetBackgroundColor", 2)

    def create_viewer_2d(self) -> 'Viewer2D':
        from experience.inf_interfaces.viewer_2d import Viewer2D

        return Viewer2D(self._vba_cast(self.viewer, "Viewer2D"))

    def create_viewer_3d(self) -> 'Viewer3D':
        from experience.inf_interfaces import Viewer3D

        # return Viewer3D(self._vba_cast(self.viewer, "Viewer3D"))
        return self.as_pyclass(Viewer3D)

    def new_camera(self) -> Camera:
        return Camera(self.viewer.NewCamera())

    def put_background_color(self, color: tuple) -> None:
        return self.viewer.PutBackgroundColor(color)

    def reframe(self) -> None:
        return self.viewer.Reframe()

    def update(self) -> None:
        return self.viewer.Update()

    def zoom_in(self) -> None:
        return self.viewer.ZoomIn()

    def zoom_out(self) -> None:
        return self.viewer.ZoomOut()

    def __repr__(self):
        return f'Viewer(name="{self.name}")'
