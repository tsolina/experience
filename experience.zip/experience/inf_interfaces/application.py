from experience.system import AnyObject, SystemService
from experience.inf_interfaces.editor import Editor
from experience.inf_interfaces import Editors, Printer, Printers, Service, Window, Windows
from experience.inf_os_idl_interfaces import FileSystem, SystemConfiguration
# from experience.types import DocumentType

class Application(AnyObject):
    def __init__(self, com):
        super().__init__(com)
        self._com = com
    '''
    @property
    def active_document(self) -> Document:
        try:
            active_doc_com = self.com_object.ActiveDocument
            doc_suffix = active_doc_com.Name.split('.')[-1]
            return document_type[doc_suffix](active_doc_com)
        except com_error:
            raise CATIAApplicationException('Is there an active document?')
    '''
    @property
    def active_editor(self) -> Editor:
        return Editor(self._com.ActiveEditor)

    @property
    def active_printer(self) -> Printer:
        return Printer(self._com.ActivePrinter)

    @property
    def active_window(self) -> Window:
        return Window(self._com.ActiveWindow)

    @property
    def cache_size(self) -> int:
        return self._com.CacheSize

    @cache_size.setter
    def cache_size(self, value: int):
        self._com.CacheSize = value

    @property
    def caption(self) -> str:
        self._com.Caption

    @caption.setter
    def caption(self, value: str):
        self._com.Caption = value

    @property
    def display_file_alerts(self) -> bool:
        return self._com.DisplayFileAlerts

    @display_file_alerts.setter
    def display_file_alerts(self, value: bool):
        self._com.DisplayFileAlerts = value

    @property
    def editors(self) -> 'Editors':
        return Editors(self._com.Editors)

    @property
    def file_system(self) -> 'FileSystem':
        return FileSystem(self._com.FileSystem)

    @property
    def full_name(self) -> str:
        return self._com.FullName

    @property
    def hso_synchronized(self) -> bool:
        return self._com.HSOSynchronized

    @hso_synchronized.setter
    def hso_synchronized(self, value: bool):
        self._com.HSOSynchronized = value

    @property
    def height(self) -> float:
        return self._com.Height

    @height.setter
    def height(self, value: float):
        self._com.Height = value

    @property
    def interactive(self) -> bool:
        return self._com.Interactive

    @interactive.setter
    def interactive(self, value: bool):
        self._com.Interactive = value

    @property
    def left(self) -> float:
        return self._com.Left

    @left.setter
    def left(self, value: float):
        self._com.Left = value

    @property
    def local_cache(self) -> str:
        return self._com.LocalCache

    @local_cache.setter
    def local_cache(self, value: str):
        self._com.LocalCache = value

    @property
    def path(self) -> str:
        return self._com.Path

    @property
    def printers(self) -> Printers:
        return Printers(self._com.Printers)

    @property
    def refresh_display(self) -> bool:
        return self._com.RefreshDisplay

    @refresh_display.setter
    def refresh_display(self, value: bool):
        self._com.RefreshDisplay = value

    @property
    def script_command(self) -> int:
        return self._com.ScriptCommand

    @script_command.setter
    def script_command(self, value: int):
        self._com.ScriptCommand = value

    @property
    def status_bar(self) -> str:
        return self._com.StatusBar

    @status_bar.setter
    def status_bar(self, value: str):
        self._com.StatusBar = value

    @property
    def system_configuration(self) -> SystemConfiguration:
        return SystemConfiguration(self._com.SystemConfiguration)

    @property
    def system_service(self) -> SystemService:
        return SystemService(self._com.SystemService)

    @property
    def top(self) -> float:
        return self._com.Top

    @top.setter
    def top(self, value: float):
        self._com.Top = value

    @property
    def undo_redo_lock(self) -> bool:
        return self._com.UndoRedoLock

    @undo_redo_lock.setter
    def undo_redo_lock(self, value: bool):
        self._com.UndoRedoLock = value

    @property
    def user_interface_language(self) -> str:
        return self._com.UserInterfaceLanguage

    @property
    def visible(self) -> bool:
        return self._com.Visible

    @visible.setter
    def visible(self, value: bool):
        self._com.Visible = value

    @property
    def width(self) -> float:
        return self._com.Width

    @width.setter
    def width(self, value: float):
        self._com.Width = value

    @property
    def windows(self) -> Windows:
        return Windows(self._com.Windows)


    def disable_new_undo_redo_transaction(self) -> None:
        return self._com.DisableNewUndoRedoTransaction()

    def enable_new_undo_redo_transaction(self) -> None:
        return self._com.EnableNewUndoRedoTransaction()

    def file_selection_box(self, i_title: str, i_extension: str, i_mode: int) -> str:
        return self._com.FileSelectionBox(i_title, i_extension, i_mode)

    def folder_selection_box(self, i_title: str) -> str:
        return self._com.FolderSelectionBox(i_title)

    def get_session_service(self, i_service: str) -> Service:
        return Service(self._com.GetSessionService(i_service))
        # return Service(self._com.GetSessionService("IDService"))

    def get_workbench_id(self) -> str:
        return self._com.GetWorkbenchId()

    def help(self, i_help_id: str) -> None:
        return self._com.Help(i_help_id)

    def quit(self) -> None:
        return self._com.Quit()

    def start_command(self, i_command_id: str) -> None:
        return self._com.StartCommand(i_command_id)

    def start_workbench(self, iworkbench_id: str) -> None:
        return self._com.StartWorkbench(iworkbench_id)

    def __repr__(self):
        return f'Application(name="{self.name}")'
