from typing import TYPE_CHECKING

from experience.system import AnyObject
if TYPE_CHECKING:
    from experience.inf_interfaces import Selection, Service

class Editor(AnyObject):
    """
                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     Editor
    """

    def __init__(self, com):
        super().__init__(com)
        self.editor = com

    @property
    def active_object(self) -> AnyObject:
        return AnyObject(self.editor.ActiveObject)

    @property
    def selection(self) -> 'Selection':
        from experience.inf_interfaces import Selection
        return Selection(self.editor.Selection)

    def GetService(self, i_service: str):
        return Service(self.editor.GetService(i_service))
        #Set Service1 = CATIA.ActiveEditor.GetService("VisuServices")

    def __repr__(self):
        return f'Editor(name="{self.name}")'
