from experience.system.any_object import AnyObject

class PageSetup(AnyObject):
    def __init__(self, com):
        super().__init__(com)
        self.page_setup = com

    @property
    def banner(self) -> str:
        return self.page_setup.Banner

    @banner.setter
    def banner(self, value: str):
        self.page_setup.Banner = value

# TODO:  use CatBannerPosition enum
    @property
    def banner_position(self) -> int:
        return self.page_setup.BannerPosition

    @banner_position.setter
    def banner_position(self, value: int):
        self.page_setup.BannerPosition = value

    @property
    def banner_size(self) -> float:
        return self.page_setup.BannerSize

    @banner_size.setter
    def banner_size(self, value: float):
        self.page_setup.BannerSize = value

    @property
    def bottom(self) -> float:
        return self.page_setup.Bottom

    @bottom.setter
    def bottom(self, value: float):
        self.page_setup.Bottom = value

    @property
    def bottom_margin(self) -> float:
        return self.page_setup.BottomMargin

    @bottom_margin.setter
    def bottom_margin(self, value: float):
        self.page_setup.BottomMargin = value

    @property
    def color(self) -> int:
        return self.page_setup.Color

    @color.setter
    def color(self, value: int):
        self.page_setup.Color = value

    @property
    def dpi(self) -> float:
        return self.page_setup.Dpi

    @dpi.setter
    def dpi(self, value: float):
        self.page_setup.Dpi = value

    @property
    def gamma(self) -> float:
        return self.page_setup.Gamma

    @gamma.setter
    def gamma(self, value: float):
        self.page_setup.Gamma = value

    @property
    def left(self) -> float:
        return self.page_setup.Left

    @left.setter
    def left(self, value: float):
        self.page_setup.Left = value

    @property
    def left_margin(self) -> float:
        return self.page_setup.LeftMargin

    @left_margin.setter
    def left_margin(self, value: float):
        self.page_setup.LeftMargin = value

    @property
    def line_cap(self) -> int:
        return self.page_setup.LineCap

    @line_cap.setter
    def line_cap(self, value: int):
        self.page_setup.LineCap = value

    @property
    def line_type_overlapping_check(self) -> bool:
        return self.page_setup.LineTypeOverlappingCheck

    @line_type_overlapping_check.setter
    def line_type_overlapping_check(self, value: bool):
        self.page_setup.LineTypeOverlappingCheck = value

    @property
    def line_type_specification(self) -> int:
        return self.page_setup.LineTypeSpecification

    @line_type_specification.setter
    def line_type_specification(self, value: int):
        self.page_setup.LineTypeSpecification = value

    @property
    def line_width_specification(self) -> int:
        return self.page_setup.LineWidthSpecification

    @line_width_specification.setter
    def line_width_specification(self, value: int):
        self.page_setup.LineWidthSpecification = value

    @property
    def logo(self) -> str:
        return self.page_setup.Logo

    @logo.setter
    def logo(self, value: str):
        self.page_setup.Logo = value

    @property
    def logo_visibility(self) -> bool:
        return self.page_setup.LogoVisibility

    @logo_visibility.setter
    def logo_visibility(self, value: bool):
        self.page_setup.LogoVisibility = value

    @property
    def maximum_size(self) -> bool:
        return self.page_setup.MaximumSize

    @maximum_size.setter
    def maximum_size(self, value: bool):
        self.page_setup.MaximumSize = value

    @property
    def orientation(self) -> int:
        return self.page_setup.Orientation

    @orientation.setter
    def orientation(self, value: int):
        self.page_setup.Orientation = value

    @property
    def paper_height(self) -> float:
        return self.page_setup.PaperHeight

    @paper_height.setter
    def paper_height(self, value: float):
        self.page_setup.PaperHeight = value

    @property
    def paper_size(self) -> int:
        return self.page_setup.PaperSize

    @paper_size.setter
    def paper_size(self, value: int):
        self.page_setup.PaperSize = value

    @property
    def paper_width(self) -> float:
        return self.page_setup.PaperWidth

    @paper_width.setter
    def paper_width(self, value: float):
        self.page_setup.PaperWidth = value

    @property
    def print_rendering_mode(self) -> int:
        return self.page_setup.PrintRenderingMode

    @print_rendering_mode.setter
    def print_rendering_mode(self, value: int):
        self.page_setup.PrintRenderingMode = value

    @property
    def quality(self) -> int:
        return self.page_setup.Quality

    @quality.setter
    def quality(self, value: int):
        self.page_setup.Quality = value

    @property
    def right_margin(self) -> float:
        return self.page_setup.RightMargin

    @right_margin.setter
    def right_margin(self, value: float):
        self.page_setup.RightMargin = value

    @property
    def rotation(self) -> int:
        return self.page_setup.Rotation

    @rotation.setter
    def rotation(self, value: float):
        self.page_setup.Rotation = value

    @property
    def scaling_1_to_1(self) -> bool:
        return self.page_setup.Scaling1To1

    @scaling_1_to_1.setter
    def scaling_1_to_1(self, value: bool):
        self.page_setup.Scaling1To1 = value

    @property
    def text_blanking(self) -> bool:
        return self.page_setup.TextBlanking

    @text_blanking.setter
    def text_blanking(self, value: bool):
        self.page_setup.TextBlanking = value

    @property
    def text_scaling(self) -> bool:
        return self.page_setup.TextScaling

    @text_scaling.setter
    def text_scaling(self, value: bool):
        self.page_setup.TextScaling = value

    @property
    def top_margin(self) -> float:
        return self.page_setup.TopMargin

    @top_margin.setter
    def top_margin(self, value: float):
        self.page_setup.TopMargin = value

    @property
    def use_3d_accuracy(self) -> bool:
        return self.page_setup.Use3DAccuracy

    @use_3d_accuracy.setter
    def use_3d_accuracy(self, value: bool):
        self.page_setup.Use3DAccuracy = value

    @property
    def use_image_size(self) -> bool:
        return self.page_setup.UseImageSize

    @use_image_size.setter
    def use_image_size(self, value: bool):
        self.page_setup.UseImageSize = value

    @property
    def white_vectors_in_black(self) -> bool:
        return self.page_setup.WhiteVectorsInBlack

    @white_vectors_in_black.setter
    def white_vectors_in_black(self, value: bool):
        self.page_setup.WhiteVectorsInBlack = value

    @property
    def zoom(self) -> float:
        return self.page_setup.Zoom

    @zoom.setter
    def zoom(self, value: float):
        self.page_setup.Zoom = value

    def __repr__(self):
        return f'PageSetup(name="{ self.name }")'
