from experience.system.any_object import AnyObject

class TextStream(AnyObject):
    """
                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     TextStream
    """

    def __init__(self, com):
        super().__init__(com)
        self.text_stream = com

    @property
    def at_end_of_line(self) -> bool:
        return self.text_stream.AtEndOfLine

    @property
    def at_end_of_stream(self) -> bool:
        return self.text_stream.AtEndOfStream

    def close(self) -> None:
        return self.text_stream.Close()

    def read(self, i_num_of_char: int) -> str:
        return self.text_stream.Read(i_num_of_char)

    def read_line(self) -> str:
        return self.text_stream.ReadLine()

    def write(self, i_written_string: str) -> None:
        return self.text_stream.Write(i_written_string)

    def __repr__(self):
        return f'TextStream(name="{ self.name }")'
