# try:
from .base_interfaces import BaseApplication, Experience
from .inf_interfaces import Application, Camera, Editor, Editors, LightSource, LighSources, PageSetup, Printer, Printers, Selection, Service
from .inf_interfaces import Viewer2D, Viewer3D, Viewer, Viewers, Viewpoint2D, Viewpoint3D, Window, Windows
from .inf_os_idl_interfaces import FileComponent, FileSystem, File, Files, Folder, Folders, SystemConfiguration, TextStream
from .knowledge_interfaces import BoolParam, EnumParam, IntParam, KnowledgeActivateObject, KnowledgeObject, Parameter, RealParam, Relation, StrParam
from .system import AnyObject, CATBaseDispatch, CATBaseUnknown, Collection, IDispatch, IUnknown, SystemService
from .types import General
from .enumeration import enumeration_types

from cat_logger import create_logger
# except Exception as e:
#     print(f"Top: {e}" )
