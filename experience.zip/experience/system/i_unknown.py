class IUnknown():
    def __init__(self):
        pass

    def __repr__(self):
        return f'IUnknown()'
