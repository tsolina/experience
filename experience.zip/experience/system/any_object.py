from typing import TYPE_CHECKING
from experience.base_interfaces.experience import Experience

if TYPE_CHECKING:
    from experience.inf_interfaces.application import Application

class AnyObject(Experience):
    """docstring for AnyObject."""

    def __init__(self, com):
        super().__init__()
        self._com = com

    @property
    def application(self) -> 'Application':
        from experience.inf_interfaces.application import Application
        return  Application(self._com.Application)

    @property
    def name(self) -> str:
        return self._com.Name

    @property
    def parent(self) -> 'AnyObject':
        return AnyObject(self._com.Parent)

    def get_item(self, id_name: str) -> 'AnyObject':
        return AnyObject(self._com.GetItem(id_name))

    def _vba_cast(self, com_object, vba_class_name):
        vba_function_name = 'generalizedCastToVBA'
        vba_code = """
        Public Function generalizedCastToVBA(obj as AnyObject) as {vba_class_name}
            set generalizedCastToVBA = obj
        End Function
        """
        return self.application.system_service.evaluate(vba_code, 1, vba_function_name, [com_object])

    def as_pyclass(self, target_class, vba_class_name=None):
        if vba_class_name is None:
            vba_class_name = target_class.__name__

        vba_function_name = 'generalizedCastToVBA'
        vba_code = """
        Public Function generalizedCastToVBA(obj as AnyObject) as {vba_class_name}
            set generalizedCastToVBA = obj
        End Function
        """

        # TODO: at least verify that target_class is instance of AnyObject
        return target_class(self._com.Application.SystemService.Evaluate(vba_code, 1, vba_function_name, [self._com]))

    def _get_safe_array(self, com_obj: 'AnyObject', method: str, tuple_length: int) -> tuple:
        vba_function_name = 'get_safe_array'
        vba_code = f"""
        Public Function {vba_function_name}({com_obj.__class__.__name__})
            Dim arr({tuple_length})
            {com_obj.__class__.__name__}.{method} arr
            {vba_function_name} = arr
        End Function
        """

        return self.application.system_service.evaluate(vba_code, 1, vba_function_name, [com_obj])

    def __repr__(self):
        return f'AnyObject(name="{self.name}")'
